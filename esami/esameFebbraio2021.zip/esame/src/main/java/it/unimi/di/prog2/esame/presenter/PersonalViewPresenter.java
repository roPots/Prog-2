package it.unimi.di.prog2.esame.presenter;

import it.unimi.di.prog2.esame.view.PersonalView;
import org.jetbrains.annotations.NotNull;

public class PersonalViewPresenter {

  public PersonalViewPresenter(@NotNull PersonalView view) {
    view.addHandlers(this);
  }

  public void addQuestion(@NotNull String s) {
    System.err.println("nuova domanda: " + s);
  }

  public void voteQuestion(int i) {
    System.err.println("voto per " + i);
  }
}
