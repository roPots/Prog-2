package it.unimi.di.prog2.esame.presenter;



import javafx.event.ActionEvent;
import javafx.event.EventHandler;

// Ho dovuto dare un nome... se volete implementare il pattern MVC invece di MVP
// per favore modificate il nome della classe e del package in Controller

public abstract class Presenter implements EventHandler<ActionEvent> {

}
